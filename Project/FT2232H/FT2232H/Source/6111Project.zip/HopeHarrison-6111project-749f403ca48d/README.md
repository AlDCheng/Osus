This is our final project for 6.111 which will be an FPGA Touch Projector
